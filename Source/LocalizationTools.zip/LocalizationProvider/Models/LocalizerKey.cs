﻿namespace LocalizationProvider.Models;

internal record struct LocalizerKey(ResourceType Type, string Culture);

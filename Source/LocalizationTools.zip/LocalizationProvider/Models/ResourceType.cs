﻿namespace LocalizationProvider.Models;

internal enum ResourceType {
    Text,
    List,
    Image,
}

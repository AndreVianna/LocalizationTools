﻿namespace LocalizationProvider.Contracts;

public interface ILocalizer {
}

﻿namespace LocalizationProvider.Contracts;

public interface ILocalizedResource {
    string Key { get; }
}

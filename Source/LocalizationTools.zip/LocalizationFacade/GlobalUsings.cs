global using System;

global using LocalizationProvider.PostgreSql.Extensions;